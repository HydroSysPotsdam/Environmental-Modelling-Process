# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 14:48:18 2018

@author: fs14746
"""

__version__ = "0.1.1"
